CREATE TABLE IF NOT EXISTS hoteles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    ciudad VARCHAR(50) NOT NULL,
    descripcion TEXT,
    precio_noche DECIMAL(10,2) NOT NULL,
    numero_habitaciones INT NOT NULL,
    imagen_principal VARCHAR(255),
    imagen_secundaria VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS reservas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hotel_id INT NOT NULL,
    nombre_cliente VARCHAR(100) NOT NULL,
    fecha_entrada DATE NOT NULL,
    fecha_salida DATE NOT NULL,
    numero_habitaciones INT NOT NULL,
    FOREIGN KEY (hotel_id) REFERENCES hoteles(id)
);

INSERT INTO hoteles (nombre, ciudad, descripcion, precio_noche, numero_habitaciones, imagen_principal, imagen_secundaria) VALUES
('Gran Sol Palace', 'Madrid', 'Hotel de lujo en pleno centro de Madrid con vistas panorámicas, spa y restaurante gourmet.', 185.00, 20, 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600', 'https://images.unsplash.com/photo-1582719508461-905c673771fd?w=800'),
('Hotel Mediterráneo', 'Barcelona', 'Hotel frente al mar con piscina infinita, terraza solar y acceso directo a la playa.', 220.00, 15, 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=600', 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800'),
('Casa Sevilla', 'Sevilla', 'Encantador hotel boutique en el barrio de Santa Cruz con patio andaluz y arquitectura tradicional.', 130.00, 10, 'https://images.unsplash.com/photo-1540541338287-41700207dee6?w=600', 'https://images.unsplash.com/photo-1585435557343-3b092031a831?w=800'),
('Madrid Business Inn', 'Madrid', 'Hotel moderno cerca del centro de negocios con salas de reuniones, gimnasio y wifi ultrarrápido.', 95.00, 30, 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=600', 'https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=800'),
('Barcelona Urban Hostel', 'Barcelona', 'Hostel vibrante en Las Ramblas con habitaciones compartidas, bar terraza y eventos sociales.', 45.00, 25, 'https://images.unsplash.com/photo-1559628233-100c798642d4?w=600', 'https://images.unsplash.com/photo-1584132967334-10e028bd69f7?w=800'),
('Sevilla Golf Resort', 'Sevilla', 'Complejo turístico con campo de golf profesional, piscinas olímpicas y restaurante de alta cocina.', 175.00, 18, 'https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?w=600', 'https://images.unsplash.com/photo-1567818735868-e71b99932e29?w=800'),
('El Retiro Suites', 'Madrid', 'Suites de lujo junto al Parque del Retiro con servicio de mayordomo y desayuno incluido.', 250.00, 8, 'https://images.unsplash.com/photo-1590490359683-658d3d23f972?w=600', 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=800')
ON DUPLICATE KEY UPDATE nombre=VALUES(nombre);

-- ============================================================
-- AUDIT TABLE: saves info every time someone makes a reservation
-- ============================================================
CREATE TABLE IF NOT EXISTS auditoria_reservas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hotel_id INT NOT NULL,
    reserva_id INT NOT NULL,
    fecha_hora DATETIME NOT NULL
);

-- ============================================================
-- TRIGGER: runs automatically after each new reservation
-- It saves: which hotel, the reservation number, and the exact time
-- ============================================================
DELIMITER //
CREATE TRIGGER trg_auditoria_reservas
AFTER INSERT ON reservas
FOR EACH ROW
BEGIN
    INSERT INTO auditoria_reservas (hotel_id, reserva_id, fecha_hora)
    VALUES (NEW.hotel_id, NEW.id, NOW());
END//
DELIMITER ;

-- ============================================================
-- STORED PROCEDURE: checks room availability and makes a reservation
-- Call it with: hotel id, customer name, check-in, check-out, # of rooms
-- It returns: status ('success' or 'error'), a message, and the reserva_id
-- ============================================================
DELIMITER //
CREATE PROCEDURE sp_realizar_reserva(
    IN p_hotel_id INT,
    IN p_nombre_cliente VARCHAR(100),
    IN p_fecha_entrada DATE,
    IN p_fecha_salida DATE,
    IN p_numero_habitaciones INT
)
BEGIN
    DECLARE total_habitaciones INT;     -- How many rooms the hotel has in total
    DECLARE reservadas INT;             -- How many rooms are already booked for these dates
    DECLARE disponibles INT;            -- How many rooms are still free
    
    -- Step 1: find out how many rooms this hotel has
    SELECT numero_habitaciones INTO total_habitaciones 
    FROM hoteles WHERE id = p_hotel_id;
    
    -- Step 2: count how many rooms are already booked for the dates we want
    -- (if a reservation's dates overlap with our dates, count those rooms)
    SELECT COALESCE(SUM(numero_habitaciones), 0) INTO reservadas
    FROM reservas
    WHERE hotel_id = p_hotel_id
        AND fecha_entrada < p_fecha_salida
        AND fecha_salida > p_fecha_entrada;
    
    -- Step 3: calculate available rooms
    SET disponibles = total_habitaciones - reservadas;
    
    -- Step 4: if there aren't enough rooms, tell the user
    IF p_numero_habitaciones > disponibles THEN
        SET @sp_status = 'error';
        SET @sp_message = CONCAT('Solo hay ', disponibles, ' habitacion(es) disponible(s)');
        SET @sp_reserva_id = 0;
    ELSE
        -- Step 5: if there ARE enough rooms, save the reservation
        INSERT INTO reservas (hotel_id, nombre_cliente, fecha_entrada, fecha_salida, numero_habitaciones)
        VALUES (p_hotel_id, p_nombre_cliente, p_fecha_entrada, p_fecha_salida, p_numero_habitaciones);
        
        SET @sp_status = 'success';
        SET @sp_message = 'Reserva confirmada';
        SET @sp_reserva_id = LAST_INSERT_ID();
    END IF;
END//
DELIMITER ;
