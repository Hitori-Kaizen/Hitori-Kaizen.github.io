# Backend of the hotel booking app (Python + Flask + MySQL)

import os
import mysql.connector
from mysql.connector import Error as DBError
from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Connects to the MySQL database using settings from docker-compose.yml
def get_db():
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "db"),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASS", "root"),
        database=os.getenv("DB_NAME", "bd1"),
    )

# Simple check to see if the backend is alive (Docker uses this)
@app.get("/health")
def health():
    return jsonify({"status": "ok"}), 200

# Creates the tables (hoteles, reservas) and fills sample data on first run
@app.post("/api/init-db")
def init_db():
    connection = None
    try:
        connection = get_db()
        cursor = connection.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS hoteles (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nombre VARCHAR(100) NOT NULL,
                ciudad VARCHAR(50) NOT NULL,
                descripcion TEXT,
                precio_noche DECIMAL(10,2) NOT NULL,
                numero_habitaciones INT NOT NULL,
                imagen_principal VARCHAR(255),
                imagen_secundaria VARCHAR(255)
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS reservas (
                id INT AUTO_INCREMENT PRIMARY KEY,
                hotel_id INT NOT NULL,
                nombre_cliente VARCHAR(100) NOT NULL,
                fecha_entrada DATE NOT NULL,
                fecha_salida DATE NOT NULL,
                numero_habitaciones INT NOT NULL,
                FOREIGN KEY (hotel_id) REFERENCES hoteles(id)
            )
        """)

        cursor.execute("SELECT COUNT(*) FROM hoteles")
        count = cursor.fetchone()[0]
        if count == 0:
            sample = [
                ("Gran Sol Palace", "Madrid", "Hotel de lujo en pleno centro de Madrid con vistas panorámicas, spa y restaurante gourmet.", 185.00, 20, "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600", "https://images.unsplash.com/photo-1582719508461-905c673771fd?w=800"),
                ("Hotel Mediterráneo", "Barcelona", "Hotel frente al mar con piscina infinita, terraza solar y acceso directo a la playa.", 220.00, 15, "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=600", "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800"),
                ("Casa Sevilla", "Sevilla", "Encantador hotel boutique en el barrio de Santa Cruz con patio andaluz y arquitectura tradicional.", 130.00, 10, "https://images.unsplash.com/photo-1540541338287-41700207dee6?w=600", "https://images.unsplash.com/photo-1585435557343-3b092031a831?w=800"),
                ("Madrid Business Inn", "Madrid", "Hotel moderno cerca del centro de negocios con salas de reuniones, gimnasio y wifi ultrarrápido.", 95.00, 30, "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=600", "https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=800"),
                ("Barcelona Urban Hostel", "Barcelona", "Hostel vibrante en Las Ramblas con habitaciones compartidas, bar terraza y eventos sociales.", 45.00, 25, "https://images.unsplash.com/photo-1559628233-100c798642d4?w=600", "https://images.unsplash.com/photo-1584132967334-10e028bd69f7?w=800"),
                ("Sevilla Golf Resort", "Sevilla", "Complejo turístico con campo de golf profesional, piscinas olímpicas y restaurante de alta cocina.", 175.00, 18, "https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?w=600", "https://images.unsplash.com/photo-1567818735868-e71b99932e29?w=800"),
                ("El Retiro Suites", "Madrid", "Suites de lujo junto al Parque del Retiro con servicio de mayordomo y desayuno incluido.", 250.00, 8, "https://images.unsplash.com/photo-1590490359683-658d3d23f972?w=600", "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=800"),
            ]
            cursor.executemany(
                "INSERT INTO hoteles (nombre, ciudad, descripcion, precio_noche, numero_habitaciones, imagen_principal, imagen_secundaria) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                sample
            )

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS auditoria_reservas (
                id INT AUTO_INCREMENT PRIMARY KEY,
                hotel_id INT NOT NULL,
                reserva_id INT NOT NULL,
                fecha_hora DATETIME NOT NULL
            )
        """)

        cursor.execute("DROP TRIGGER IF EXISTS trg_auditoria_reservas")
        cursor.execute("""
            CREATE TRIGGER trg_auditoria_reservas
            AFTER INSERT ON reservas
            FOR EACH ROW
            INSERT INTO auditoria_reservas (hotel_id, reserva_id, fecha_hora)
            VALUES (NEW.hotel_id, NEW.id, NOW())
        """)

        cursor.execute("DROP PROCEDURE IF EXISTS sp_realizar_reserva")
        cursor.execute("""
            CREATE PROCEDURE sp_realizar_reserva(
                IN p_hotel_id INT,
                IN p_nombre_cliente VARCHAR(100),
                IN p_fecha_entrada DATE,
                IN p_fecha_salida DATE,
                IN p_numero_habitaciones INT
            )
            BEGIN
                DECLARE total_habitaciones INT;
                DECLARE reservadas INT;
                DECLARE disponibles INT;

                SELECT numero_habitaciones INTO total_habitaciones
                FROM hoteles WHERE id = p_hotel_id;

                SELECT COALESCE(SUM(numero_habitaciones), 0) INTO reservadas
                FROM reservas
                WHERE hotel_id = p_hotel_id
                    AND fecha_entrada < p_fecha_salida
                    AND fecha_salida > p_fecha_entrada;

                SET disponibles = total_habitaciones - reservadas;

                IF p_numero_habitaciones > disponibles THEN
                    SET @sp_status = 'error';
                    SET @sp_message = CONCAT('Solo hay ', disponibles, ' habitacion(es) disponible(s)');
                    SET @sp_reserva_id = 0;
                ELSE
                    INSERT INTO reservas (hotel_id, nombre_cliente, fecha_entrada, fecha_salida, numero_habitaciones)
                    VALUES (p_hotel_id, p_nombre_cliente, p_fecha_entrada, p_fecha_salida, p_numero_habitaciones);

                    SET @sp_status = 'success';
                    SET @sp_message = 'Reserva confirmada';
                    SET @sp_reserva_id = LAST_INSERT_ID();
                END IF;
            END
        """)

        connection.commit()
        return jsonify({"status": "success", "message": "Base de datos inicializada correctamente"}), 200
    except DBError as e:
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        if connection and connection.is_connected():
            connection.close()

# Searches hotels by city and filters by available rooms for the given dates
@app.get("/api/hoteles")
def buscar_hoteles():
    ciudad = request.args.get("ciudad", "")
    entrada = request.args.get("entrada", "")
    salida = request.args.get("salida", "")
    habitaciones = request.args.get("habitaciones", "1")

    connection = None
    try:
        connection = get_db()
        cursor = connection.cursor(dictionary=True)

        if entrada and salida:
            # Substracts already booked rooms from total rooms, only shows hotels with enough free rooms
            sql = """
                SELECT h.*,
                    (h.numero_habitaciones - COALESCE(SUM(r.numero_habitaciones), 0)) AS habitaciones_disponibles
                FROM hoteles h
                LEFT JOIN reservas r ON h.id = r.hotel_id
                    AND r.fecha_entrada < %s
                    AND r.fecha_salida > %s
                WHERE LOWER(h.ciudad) LIKE %s
                GROUP BY h.id
                HAVING habitaciones_disponibles >= %s
                ORDER BY h.precio_noche ASC
            """
            cursor.execute(sql, (salida, entrada, f"%{ciudad.lower()}%", int(habitaciones)))
        else:
            # No dates selected: just show all hotels in that city
            sql = """
                SELECT h.*, h.numero_habitaciones AS habitaciones_disponibles
                FROM hoteles h
                WHERE LOWER(h.ciudad) LIKE %s
                ORDER BY h.precio_noche ASC
            """
            cursor.execute(sql, (f"%{ciudad.lower()}%",))

        hoteles = cursor.fetchall()
        for h in hoteles:
            h["precio_noche"] = float(h["precio_noche"])

        return jsonify(hoteles), 200
    except DBError as e:
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        if connection and connection.is_connected():
            connection.close()

# Gets all the info for one specific hotel by its ID (used for the detail page)
@app.get("/api/hoteles/<int:hotel_id>")
def detalle_hotel(hotel_id):
    connection = None
    try:
        connection = get_db()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM hoteles WHERE id = %s", (hotel_id,))
        hotel = cursor.fetchone()
        if not hotel:
            return jsonify({"status": "error", "message": "Hotel no encontrado"}), 404
        hotel["precio_noche"] = float(hotel["precio_noche"])
        return jsonify(hotel), 200
    except DBError as e:
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        if connection and connection.is_connected():
            connection.close()

# Makes a reservation: validates input, calls stored procedure to check availability, saves or rejects
@app.post("/api/reservas")
def crear_reserva():
        data = request.get_json()
        hotel_id = data.get("hotel_id")
        nombre_cliente = data.get("nombre_cliente", "").strip()
        fecha_entrada = data.get("fecha_entrada", "")
        fecha_salida = data.get("fecha_salida", "")
        num_habitaciones = data.get("numero_habitaciones", 0)

        # These ifs check that the user filled in everything correctly
        if not hotel_id or not nombre_cliente or not fecha_entrada or not fecha_salida:
            return jsonify({"status": "error", "message": "Todos los campos son obligatorios"}), 400

        if not num_habitaciones or int(num_habitaciones) < 1:
            return jsonify({"status": "error", "message": "Debe reservar al menos 1 habitación"}), 400

        try:
            entrada = datetime.strptime(fecha_entrada, "%Y-%m-%d").date()
            salida = datetime.strptime(fecha_salida, "%Y-%m-%d").date()
        except ValueError:
            return jsonify({"status": "error", "message": "Formato de fecha inválido"}), 400

        if salida <= entrada:
            return jsonify({"status": "error", "message": "La fecha de salida debe ser posterior a la de entrada"}), 400

        connection = None
        try:
            connection = get_db()
            cursor = connection.cursor()

            # Calls the stored procedure that checks rooms and inserts the reservation
            cursor.callproc('sp_realizar_reserva', [hotel_id, nombre_cliente, fecha_entrada, fecha_salida, int(num_habitaciones)])
            cursor.execute("SELECT @sp_status, @sp_message, @sp_reserva_id")
            row = cursor.fetchone()
            status = row[0]
            message = row[1]
            reserva_id = row[2]

            connection.commit()

            if status == 'success':
                return jsonify({
                    "status": "success",
                    "message": f"Reserva confirmada para {nombre_cliente}",
                    "reserva_id": reserva_id
                }), 201
            else:
                return jsonify({"status": "error", "message": message}), 400

        except DBError as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        finally:
            if connection and connection.is_connected():
                connection.close()

# Starts the Flask web server on port 5000 so the frontend can talk to it
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
