// Frontend of the hotel booking app. Talks to the backend via fetch()
const API = '/api';
let ultimaBusqueda = {};

// Gets references to all the HTML elements we need
const orb = document.getElementById('searchOrb');
const orbLabel = document.getElementById('orbLabel');
const overlay = document.getElementById('searchOverlay');
const closeBtn = document.getElementById('closeOverlay');
const searchForm = document.getElementById('searchForm');
const mainContent = document.getElementById('mainContent');
const hero = document.getElementById('hero');
const hotelGrid = document.getElementById('hotelGrid');
const resultsTitle = document.getElementById('resultsTitle');
const resultsBadge = document.getElementById('resultsBadge');
const editSearchBtn = document.getElementById('editSearchBtn');
const hotelListView = document.getElementById('hotelListView');
const detailView = document.getElementById('detailView');
const detailContent = document.getElementById('detailContent');
const backBtn = document.getElementById('backBtn');
const confirmation = document.getElementById('confirmation');
const confirmMsg = document.getElementById('confirmMsg');
const newSearchBtn = document.getElementById('newSearchBtn');
const toast = document.getElementById('toast');

// Search button (floating orb) — opens/closes the search overlay
orb.addEventListener('mouseenter', () => orbLabel.classList.add('visible'));
orb.addEventListener('mouseleave', () => orbLabel.classList.remove('visible'));
orb.addEventListener('click', () => { overlay.classList.add('open'); setMinDates(); });
closeBtn.addEventListener('click', () => overlay.classList.remove('open'));

// Clicking outside the search panel closes it
overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.classList.remove('open'); });

editSearchBtn.addEventListener('click', () => { overlay.classList.add('open'); setMinDates(); });
backBtn.addEventListener('click', showList);
newSearchBtn.addEventListener('click', () => { confirmation.classList.remove('active'); resetToHero(); });

// Sets min date to today so users can't pick past dates
function setMinDates() {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('entrada').min = today;
    document.getElementById('salida').min = today;
}

// Shows a small popup message at the bottom of the screen
function toastMsg(msg, type) {
    toast.textContent = msg;
    toast.className = 'toast ' + type + ' show';
    setTimeout(() => toast.classList.remove('show'), 4000);
}

// Goes back to the home screen (hero page)
function resetToHero() {
    mainContent.classList.add('hidden');
    hero.style.display = 'flex';
    hotelListView.classList.add('active');
    detailView.classList.remove('active');
    confirmation.classList.remove('active');
    hotelGrid.innerHTML = '';
}

// Search form: collects data and sends it to the backend to find matching hotels
searchForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    overlay.classList.remove('open');

    // Gets what the user typed in the search form
    const ciudad = document.getElementById('ciudad').value.trim();
    const entrada = document.getElementById('entrada').value;
    const salida = document.getElementById('salida').value;
    const habitaciones = document.getElementById('habitaciones').value;

    // Validates that all fields are filled in
    if (!ciudad || !entrada || !salida) { toastMsg('Completa todos los campos', 'error'); return; }
    if (new Date(salida) <= new Date(entrada)) { toastMsg('La salida debe ser posterior a la entrada', 'error'); return; }

    ultimaBusqueda = { ciudad, entrada, salida, habitaciones };

    // Hides the hero and shows the results area
    hero.style.display = 'none';
    mainContent.classList.remove('hidden');
    detailView.classList.remove('active');
    hotelListView.classList.add('active');
    confirmation.classList.remove('active');

    // Shows a loading spinner while waiting for the backend
    hotelGrid.innerHTML = '<div class="loading"><div class="spinner"></div>Buscando hoteles disponibles...</div>';
    resultsTitle.textContent = `Hoteles en ${ciudad}`;

    try {
        // Sends GET /api/hoteles with the search params
        const params = new URLSearchParams({ ciudad, entrada, salida, habitaciones });
        const res = await fetch(`${API}/hoteles?${params}`);
        if (!res.ok) throw new Error('Error del servidor');
        const hoteles = await res.json();
        renderHoteles(hoteles);
    } catch (err) {
        // Shows error message if something went wrong
        hotelGrid.innerHTML = '<div class="no-results"><h3>Error de conexión</h3><p>No se pudo conectar con el servidor</p></div>';
        toastMsg('Error al buscar hoteles', 'error');
    }
});

// Takes hotel data from the backend and turns it into clickable HTML cards
function renderHoteles(hoteles) {
    if (!hoteles || hoteles.length === 0) {
        // Shows "no results" when no hotels match
        hotelGrid.innerHTML = '<div class="no-results"><h3>Sin resultados</h3><p>No hay hoteles disponibles en esta ciudad para las fechas seleccionadas</p></div>';
        resultsBadge.textContent = '0 hoteles';
        return;
    }
    resultsBadge.textContent = `${hoteles.length} hoteles`;
    // Builds HTML for each hotel card
    hotelGrid.innerHTML = hoteles.map(h => {
        const img = h.imagen_principal || 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600';
        return `
            <div class="hotel-card" data-id="${h.id}">
                <img src="${img}" alt="${h.nombre}" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600'">
                <div class="hotel-card-body">
                    <h3>${h.nombre}</h3>
                    <div class="city">${h.ciudad}</div>
                    <div class="hotel-card-footer">
                        <div class="price">${Number(h.precio_noche).toFixed(2)}€ <small>/ noche</small></div>
                        <div class="avail">${h.habitaciones_disponibles} hab. libres</div>
                    </div>
                </div>
            </div>
        `;
    }).join('');

    // Makes each card clickable — shows hotel detail on click
    document.querySelectorAll('.hotel-card').forEach(card => {
        card.addEventListener('click', () => showDetail(card.dataset.id));
    });
}

// Fetches one hotel's full info from the backend and shows the detail view
async function showDetail(hotelId) {
    hotelListView.classList.remove('active');
    detailView.classList.add('active');
    confirmation.classList.remove('active');
    detailContent.innerHTML = '<div class="loading"><div class="spinner"></div>Cargando...</div>';

    try {
        // Asks the backend for this hotel's data
        const res = await fetch(`${API}/hoteles/${hotelId}`);
        if (!res.ok) throw new Error('Not found');
        const h = await res.json();
        renderDetail(h);
    } catch (err) {
        detailContent.innerHTML = '<div class="no-results"><h3>Error</h3><p>No se pudo cargar el hotel</p></div>';
    }
}

// Builds the HTML for the hotel detail page (image, description, price, booking form)
function renderDetail(h) {
    const img = h.imagen_secundaria || h.imagen_principal || 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800';
    const entrada = ultimaBusqueda.entrada || '';
    const salida = ultimaBusqueda.salida || '';
    let noches = 0;
    // Calculates how many nights the stay lasts
    if (entrada && salida) {
        const d1 = new Date(entrada), d2 = new Date(salida);
        noches = Math.max(0, Math.ceil((d2 - d1) / 86400000));
    }
    const total = noches * Number(h.precio_noche);

    detailContent.innerHTML = `
        <div class="detail-hero">
            <img src="${img}" alt="${h.nombre}" onerror="this.src='https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800'">
            <div class="detail-hero-overlay">
                <h2>${h.nombre}</h2>
                <div class="city-label">📍 ${h.ciudad}</div>
            </div>
        </div>
        <div class="detail-grid">
            <div>
                <h3 style="margin-bottom:12px;font-weight:700;">Sobre este hotel</h3>
                <div class="detail-desc">${h.descripcion}</div>
            </div>
            <div class="booking-card">
                <h3 style="font-weight:700;">Reservar</h3>
                <div class="total">${Number(h.precio_noche).toFixed(2)}€ <small>x ${noches} noche${noches!==1?'s':''}</small></div>
                <div class="total" style="font-size:1.2rem;margin-top:-8px;">Total: ${total.toFixed(2)}€</div>
                <div class="booking-form">
                    <div>
                        <label>Nombre completo</label>
                        <input type="text" id="nombreCliente" placeholder="Tu nombre" required>
                    </div>
                    <div>
                        <label>Entrada</label>
                        <input type="date" id="bookEntrada" value="${entrada}">
                    </div>
                    <div>
                        <label>Salida</label>
                        <input type="date" id="bookSalida" value="${salida}">
                    </div>
                    <div>
                        <label>Habitaciones</label>
                        <input type="number" id="bookHabitaciones" min="1" value="${ultimaBusqueda.habitaciones || 1}">
                    </div>
                    <button class="btn-book" id="btnBook">Confirmar reserva</button>
                </div>
            </div>
        </div>
    `;

    // Triggers the booking when user clicks "Confirmar reserva"
    document.getElementById('btnBook').addEventListener('click', () => bookHotel(h.id));
}

// Sends reservation data to the backend; the stored procedure checks room availability
async function bookHotel(hotelId) {
    const nombre = document.getElementById('nombreCliente').value.trim();
    const entrada = document.getElementById('bookEntrada').value;
    const salida = document.getElementById('bookSalida').value;
    const habitaciones = document.getElementById('bookHabitaciones').value;

    // Validates the form fields before sending
    if (!nombre) { toastMsg('Introduce tu nombre', 'error'); return; }
    if (!entrada || !salida) { toastMsg('Selecciona las fechas', 'error'); return; }
    if (new Date(salida) <= new Date(entrada)) { toastMsg('La salida debe ser posterior a la entrada', 'error'); return; }

    const btn = document.getElementById('btnBook');
    btn.disabled = true;
    btn.textContent = 'Reservando...';

    try {
        // POSTs the reservation to the backend; stored procedure checks availability
        const res = await fetch(`${API}/reservas`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                hotel_id: hotelId,
                nombre_cliente: nombre,
                fecha_entrada: entrada,
                fecha_salida: salida,
                numero_habitaciones: parseInt(habitaciones)
            })
        });
        const data = await res.json();
        if (data.status === 'success') {
            // Shows the success screen
            detailView.classList.remove('active');
            confirmation.classList.add('active');
            confirmMsg.textContent = `Gracias, ${nombre}. Tu reserva en el hotel ha sido confirmada.`;
            toastMsg('Reserva confirmada', 'success');
        } else {
            // Shows error (e.g. not enough rooms)
            toastMsg(data.message || 'Error al reservar', 'error');
            btn.disabled = false;
            btn.textContent = 'Confirmar reserva';
        }
    } catch (err) {
        toastMsg('Error de conexión', 'error');
        btn.disabled = false;
        btn.textContent = 'Confirmar reserva';
    }
}

// Goes back to the hotel list from the detail view
function showList() {
    detailView.classList.remove('active');
    hotelListView.classList.add('active');
    confirmation.classList.remove('active');
}

// Calls the backend to create tables and insert sample data when the page loads
(async function initDB() {
    try {
        await fetch(`${API}/init-db`, { method: 'POST' });
    } catch (_) {}
})();